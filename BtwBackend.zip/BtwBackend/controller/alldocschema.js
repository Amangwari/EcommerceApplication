
const express=require('express')


 const bankprofile=require('../model/bankdetailsschema')

const businessprofile=require('../model/businessprofileschema')

const contactprofile=require('../model/contactprofileschema')

const ProductDocsprofile=require('../model/productdocsSchema')


const businessprofilee=require('../model/sellerbusinessSchema')
const sellerdocInfos=require('../model/sellerdocschema')
const bankdocumentschema=require('../model/bankdetailsschema')
const ProductdocSchema=require('../model/productdocsSchema')


















