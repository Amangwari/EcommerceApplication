const express = require("express");
require("./db/conn");

const app = express();

const cors = require("cors");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const mongoose = require("mongoose");
const port = 5000;
const router = require("./routes.js/productroute");
const admin = require("./routes.js/adminroutes");
const session = require('express-session');

const { Router } = require("express");


app.use(cors());

// app.use(session({
//   secret: 'my-secret',
//   resave: false,
//   saveUninitialized: true
// }));

// changed by aman
app.use('/addsellerinfo', Router)

app.use(express.json());


app.use(bodyParser.urlencoded({ extended: false }));

app.use(cookieParser());

app.use(router);



app.use(admin)


app.use('/images', express.static('uploads'));




app.listen(port, () => {
  
  console.log("server start at 5000")

});

